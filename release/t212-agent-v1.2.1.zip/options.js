document.getElementById('save').addEventListener('click', saveOptions);

function saveOptions() {
  const apiKey = document.getElementById('apiKey').value.trim();
  const apiSecret = document.getElementById('apiSecret').value.trim();
  const environment = document.getElementById('environment').value;
  const useProxy = document.getElementById('useProxy').checked;
  const proxyUrl = document.getElementById('proxyUrl').value.trim() || 'http://127.0.0.1:8765';
  var autoEl = document.getElementById('autoRefreshSeconds');
  const autoRefreshSeconds = autoEl ? Math.max(0, parseInt(autoEl.value, 10) || 0) : 0;
  const opacity = Math.min(1, Math.max(0, parseFloat(document.getElementById('opacity').value) ?? 1));
  const language = (document.getElementById('language') && document.getElementById('language').value) || 'zh';
  const openRouterApiKey = (document.getElementById('openRouterApiKey') && document.getElementById('openRouterApiKey').value) ? document.getElementById('openRouterApiKey').value.trim() : '';
  const openRouterModel = (document.getElementById('openRouterModel') && document.getElementById('openRouterModel').value) ? document.getElementById('openRouterModel').value.trim() : 'qwen/qwen3.5-plus-02-15:online';
  const serperApiKey = (document.getElementById('serperApiKey') && document.getElementById('serperApiKey').value) ? document.getElementById('serperApiKey').value.trim() : '';
  const customAnalysisApiUrl = (document.getElementById('customAnalysisApiUrl') && document.getElementById('customAnalysisApiUrl').value) ? document.getElementById('customAnalysisApiUrl').value.trim() : '';
  const miroMindUrl = (document.getElementById('miroMindUrl') && document.getElementById('miroMindUrl').value) ? document.getElementById('miroMindUrl').value.trim() : '';

  chrome.storage.local.set({
    apiKey,
    apiSecret,
    environment: environment === 'live' ? 'live' : 'demo',
    useProxy,
    proxyUrl: proxyUrl.replace(/\/$/, ''),
    autoRefreshSeconds,
    opacity,
    language,
    openRouterApiKey,
    openRouterModel,
    serperApiKey,
    customAnalysisApiUrl,
    miroMindUrl: miroMindUrl || 'https://dr.miromind.ai/'
  }, function() {
    var status = document.getElementById('status');
    status.textContent = '已保存';
    setTimeout(function() { status.textContent = ''; }, 2000);
  });
}

function loadOptions() {
  chrome.storage.local.get(['apiKey', 'apiSecret', 'environment', 'useProxy', 'proxyUrl', 'autoRefreshSeconds', 'opacity', 'language', 'openRouterApiKey', 'openRouterModel', 'serperApiKey', 'customAnalysisApiUrl', 'miroMindUrl'], function(r) {
    document.getElementById('apiKey').value = r.apiKey || '';
    document.getElementById('apiSecret').value = r.apiSecret || '';
    document.getElementById('environment').value = (r.environment === 'live' ? 'live' : 'demo');
    document.getElementById('useProxy').checked = !!r.useProxy;
    document.getElementById('proxyUrl').value = r.proxyUrl || 'http://127.0.0.1:8765';
    var autoEl = document.getElementById('autoRefreshSeconds');
    if (autoEl) autoEl.value = Math.max(0, parseInt(r.autoRefreshSeconds, 10) || 0);
    var opacityEl = document.getElementById('opacity');
    var opacityVal = Math.min(1, Math.max(0, parseFloat(r.opacity) ?? 1));
    if (opacityEl) { opacityEl.value = opacityVal; }
    var opacityValueEl = document.getElementById('opacityValue');
    if (opacityValueEl) opacityValueEl.textContent = Math.round(opacityVal * 100) + '%';
    var langEl = document.getElementById('language');
    if (langEl) langEl.value = r.language || 'zh';
    var openRouterEl = document.getElementById('openRouterApiKey');
    if (openRouterEl) openRouterEl.value = r.openRouterApiKey || '';
    var openRouterModelEl = document.getElementById('openRouterModel');
    if (openRouterModelEl) openRouterModelEl.value = r.openRouterModel || 'qwen/qwen3.5-plus-02-15:online';
    var serperEl = document.getElementById('serperApiKey');
    if (serperEl) serperEl.value = r.serperApiKey || '';
    var customApiEl = document.getElementById('customAnalysisApiUrl');
    if (customApiEl) customApiEl.value = r.customAnalysisApiUrl || '';
    var miroUrlEl = document.getElementById('miroMindUrl');
    if (miroUrlEl) miroUrlEl.value = r.miroMindUrl || 'https://dr.miromind.ai/';
  });
}
var opacityInput = document.getElementById('opacity');
if (opacityInput) opacityInput.addEventListener('input', function() {
  var v = document.getElementById('opacityValue');
  if (v) v.textContent = Math.round(parseFloat(this.value) * 100) + '%';
});

loadOptions();
