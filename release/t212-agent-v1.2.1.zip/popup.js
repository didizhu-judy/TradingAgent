import { getAccountSummary, getPositions, getConfig, getCachedData, setCachedData, getRateLimitUntil, setRateLimitUntil, getMarketAnalysisFromConfig, getPromptForMiroMind, getWatchlistItems, getDefaultWatchlistItems, getDefaultWatchlistWithQuotes, enrichWatchlistItemsWithQuotes, getCustomWatchlistItems, addCustomWatchlistItem, getQuoteByTicker } from './api.js';
import { t } from './i18n.js';
import {
  sortPositions,
  renderSummaryRows,
  renderCashRows,
  renderPositionsList,
  renderPositionDetail,
  renderWatchlistList,
  renderWatchlistSearchResult
} from './app-core.js';

const el = {
  empty: document.getElementById('state-empty'),
  loading: document.getElementById('state-loading'),
  error: document.getElementById('state-error'),
  content: document.getElementById('content'),
  summaryRows: document.getElementById('summaryRows'),
  positionsList: document.getElementById('positionsList'),
  watchlistList: document.getElementById('watchlistList'),
  watchlistTickerInput: document.getElementById('watchlistTickerInput'),
  watchlistSearch: document.getElementById('watchlistSearch'),
  watchlistSearchResult: document.getElementById('watchlistSearchResult'),
  watchlistSearchError: document.getElementById('watchlistSearchError'),
  cashRows: document.getElementById('cashRows'),
  positionDetailContent: document.getElementById('positionDetailContent'),
  viewMain: document.getElementById('view-main'),
  viewWatchlist: document.getElementById('view-watchlist'),
  viewPositionDetail: document.getElementById('view-position-detail'),
  positionsSort: document.getElementById('positionsSort'),
  detailBack: document.getElementById('detailBack'),
  lastUpdatedStatus: document.getElementById('lastUpdatedStatus'),
  lastUpdatedStatusAnalysis: document.getElementById('lastUpdatedStatusAnalysis'),
  refresh: document.getElementById('refresh'),
  openOptions: document.getElementById('openOptions'),
  statusBarOptions: document.getElementById('statusBarOptions'),
  statusBarSidePanel: document.getElementById('statusBarSidePanel'),
  themeToggle: document.getElementById('themeToggle'),
  viewAnalysis: document.getElementById('view-analysis'),
  analysisGenerate: document.getElementById('analysisGenerate'),
  analysisError: document.getElementById('analysisError'),
  analysisResult: document.getElementById('analysisResult'),
  analysisBack: document.getElementById('analysisBack'),
  watchlistBack: document.getElementById('watchlistBack'),
  btnAnalysis: document.getElementById('btnAnalysis'),
  btnWatchlist: document.getElementById('btnWatchlist'),
  statusBarOptionsFromAnalysis: document.getElementById('statusBarOptionsFromAnalysis'),
  statusBarSidePanelFromAnalysis: document.getElementById('statusBarSidePanelFromAnalysis'),
  analysisModelSelect: document.getElementById('analysisModelSelect'),
  analysisLanguageSelect: document.getElementById('analysisLanguageSelect'),
  analysisCopyAndOpenMiroMind: document.getElementById('analysisCopyAndOpenMiroMind'),
  analysisMiroMindStatus: document.getElementById('analysisMiroMindStatus'),
  analysisPromptInput: document.getElementById('analysisPromptInput'),
  analysisResetPrompt: document.getElementById('analysisResetPrompt'),
  analysisCopyPrompt: document.getElementById('analysisCopyPrompt'),
  analysisPromptStatus: document.getElementById('analysisPromptStatus'),
  analysisPromptEditableHint: document.getElementById('analysisPromptEditableHint'),
  analysisOpenMiroMindSite: document.getElementById('analysisOpenMiroMindSite'),
  analysisOpenChatGPTSite: document.getElementById('analysisOpenChatGPTSite'),
  analysisOpenPerplexitySite: document.getElementById('analysisOpenPerplexitySite')
};

let state = {
  summary: null,
  positions: [],
  watchlist: [],
  watchlistLastUpdated: 0,
  watchlistError: '',
  watchlistSearchQuote: null,
  cash: null,
  sortKey: 'value',
  lastUpdated: 0,
  currency: '',
  autoRefreshSeconds: 0,
  currentDetailIndex: null,
  lang: 'zh'
};

function applyTheme(config) {
  if (!config) return;
  const opacity = Math.max(0, Math.min(1, Number(config.opacity) ?? 1));
  document.documentElement.style.setProperty('--app-opacity', String(opacity));
  document.documentElement.toggleAttribute('data-low-opacity', opacity < 0.4);
  const theme = config.theme === 'dark' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', theme);
  const lang = config.language === 'en' ? 'en' : 'zh';
  if (el.themeToggle) el.themeToggle.title = theme === 'light' ? t(lang, 'theme_switch_dark') : t(lang, 'theme_switch_light');
}

function applyI18n(lang) {
  const L = lang === 'en' ? 'en' : 'zh';
  document.documentElement.lang = L === 'en' ? 'en' : 'zh-CN';
  document.querySelectorAll('[data-i18n]').forEach(node => {
    const key = node.getAttribute('data-i18n');
    if (key) node.textContent = t(L, key);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(node => {
    const key = node.getAttribute('data-i18n-placeholder');
    if (key) node.setAttribute('placeholder', t(L, key));
  });
}

function formatLastUpdatedLabel(ms, autoRefreshSeconds) {
  if (!ms) return '';
  const d = new Date(ms);
  const locale = state.lang === 'en' ? 'en-GB' : 'zh-CN';
  let text = t(state.lang, 'last_updated') + ' ' + d.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  if (autoRefreshSeconds > 0) text += ' · ' + autoRefreshSeconds + ' ' + t(state.lang, 'auto_refresh_in');
  return text;
}

function show(which) {
  if (el.empty) el.empty.classList.add('hidden');
  if (el.loading) el.loading.classList.add('hidden');
  if (el.error) el.error.classList.add('hidden');
  if (el.content) el.content.classList.add('hidden');
  if (which === 'empty' && el.empty) el.empty.classList.remove('hidden');
  else if (which === 'loading' && el.loading) el.loading.classList.remove('hidden');
  else if (which === 'error' && el.error) el.error.classList.remove('hidden');
  else if (which === 'content' && el.content) el.content.classList.remove('hidden');
}

function setError(msg) {
  const msgEl = document.getElementById('errorMessage');
  if (msgEl) {
    let str = '请求失败';
    if (msg != null && typeof msg === 'string') str = msg;
    else if (msg instanceof Error && msg.message) str = msg.message;
    else if (msg && typeof msg === 'object') {
      const m = msg.message ?? msg.error ?? msg.msg ?? msg.statusText ?? msg.reason;
      if (typeof m === 'string') str = m;
      else if (m && typeof m === 'object' && typeof m.message === 'string') str = m.message;
      else try { str = JSON.stringify(msg); } catch (_) { str = '请求失败'; }
    }
    msgEl.textContent = (typeof str === 'string' && str !== '[object Object]') ? str : '请求失败';
  }
  show('error');
}

function setTab(activeTab) {
  const tabs = [el.tabOverview, el.tabCash, el.tabMore];
  const panels = [el.viewOverview, el.viewCash, el.viewMore];
  tabs.forEach((t) => {
    if (!t) return;
    t.classList.toggle('active', t === activeTab);
    t.setAttribute('aria-selected', t === activeTab ? 'true' : 'false');
  });
  panels.forEach((p, i) => {
    if (!p) return;
    p.classList.toggle('active', p === panels[tabs.indexOf(activeTab)]);
  });
  if (el.viewPositionDetail) el.viewPositionDetail.classList.remove('active');
}

function showPositionDetail(index) {
  state.currentDetailIndex = index;
  const sorted = sortPositions(state.positions, state.sortKey);
  const position = sorted[index];
  if (!position) return;
  if (el.viewMain) el.viewMain.classList.remove('active');
  if (el.viewPositionDetail) el.viewPositionDetail.classList.add('active');
  if (el.positionDetailContent) {
    el.positionDetailContent.innerHTML = renderPositionDetail(position, state.currency, state.lang);
  }
  if (el.detailBack) el.detailBack.focus();
}

function backFromDetail() {
  state.currentDetailIndex = null;
  if (el.viewPositionDetail) el.viewPositionDetail.classList.remove('active');
  if (el.viewMain) el.viewMain.classList.add('active');
}

function showView(name) {
  if (el.viewMain) el.viewMain.classList.toggle('active', name === 'main');
  if (el.viewWatchlist) el.viewWatchlist.classList.toggle('active', name === 'watchlist');
  if (el.viewPositionDetail) el.viewPositionDetail.classList.toggle('active', name === 'detail');
  if (el.viewAnalysis) el.viewAnalysis.classList.toggle('active', name === 'analysis');
  if (name === 'analysis') getConfig().then(c => {
    if (el.analysisModelSelect) el.analysisModelSelect.value = c.openRouterModel || '';
    if (el.analysisLanguageSelect) el.analysisLanguageSelect.value = c.analysisLanguage || 'follow';
    syncAnalysisPromptEditor(true, c);
  });
}

function getEffectiveAnalysisLang() {
  return (el.analysisLanguageSelect && el.analysisLanguageSelect.value !== 'follow') ? el.analysisLanguageSelect.value : state.lang;
}

function getDefaultAnalysisPrompt() {
  return getPromptForMiroMind(state.positions, state.summary, getEffectiveAnalysisLang());
}

async function syncAnalysisPromptEditor(forceOverwrite = false, config) {
  const cfg = config || await getConfig();
  const editable = !cfg.customAnalysisApiUrl;
  const defaultPrompt = getDefaultAnalysisPrompt();
  if (el.analysisPromptInput) {
    if (forceOverwrite || !el.analysisPromptInput.value.trim()) {
      el.analysisPromptInput.value = defaultPrompt;
    }
    el.analysisPromptInput.readOnly = !editable;
    el.analysisPromptInput.classList.toggle('readonly', !editable);
  }
  if (el.analysisPromptEditableHint) {
    el.analysisPromptEditableHint.textContent = t(state.lang, editable ? 'analysis_prompt_editable' : 'analysis_prompt_readonly');
  }
}

function tickerKey(value) {
  return String(value || '').trim().toUpperCase().split('_')[0];
}

function mergeWatchlistItems(primary, extra) {
  const out = [];
  const seen = new Set();
  [primary, extra].forEach(list => {
    (Array.isArray(list) ? list : []).forEach(item => {
      const key = tickerKey(item && (item.ticker || item.symbol));
      if (!key || seen.has(key)) return;
      seen.add(key);
      out.push({ ...item });
    });
  });
  return out;
}

function isTickerInWatchlist(ticker) {
  const key = tickerKey(ticker);
  if (!key) return false;
  return (state.watchlist || []).some(item => tickerKey(item && (item.ticker || item.symbol)) === key);
}

function quoteToWatchlistItem(quote) {
  return {
    ticker: tickerKey(quote && (quote.symbol || quote.ticker)),
    name: quote && quote.name ? quote.name : (quote && quote.ticker ? quote.ticker : '—'),
    price: quote && quote.currentPrice != null ? quote.currentPrice : null,
    change: quote && quote.change != null ? quote.change : null,
    changePct: quote && quote.changePct != null ? quote.changePct : null
  };
}

function renderWatchlistSearchCard() {
  if (!el.watchlistSearchResult) return;
  if (!state.watchlistSearchQuote) {
    el.watchlistSearchResult.classList.add('hidden');
    el.watchlistSearchResult.innerHTML = '';
    return;
  }
  const inWatchlist = isTickerInWatchlist(state.watchlistSearchQuote.ticker || state.watchlistSearchQuote.symbol);
  el.watchlistSearchResult.innerHTML = renderWatchlistSearchResult(state.watchlistSearchQuote, state.lang, inWatchlist);
  el.watchlistSearchResult.classList.remove('hidden');
  const addBtn = document.getElementById('watchlistAddFromSearch');
  if (addBtn) {
    addBtn.addEventListener('click', () => { addSearchedQuoteToWatchlist(); });
  }
}

async function addSearchedQuoteToWatchlist() {
  if (!state.watchlistSearchQuote) return;
  const item = quoteToWatchlistItem(state.watchlistSearchQuote);
  if (!item.ticker) return;
  if (isTickerInWatchlist(item.ticker)) {
    renderWatchlistSearchCard();
    return;
  }
  try {
    await addCustomWatchlistItem(item);
    state.watchlist = mergeWatchlistItems(state.watchlist, [item]);
    state.watchlist = await enrichWatchlistItemsWithQuotes(state.watchlist, true);
    renderAll();
  } catch (err) {
    if (el.watchlistSearchError) {
      el.watchlistSearchError.textContent = err && err.message ? err.message : '加入自选失败';
      el.watchlistSearchError.classList.remove('hidden');
    }
  }
}

async function searchWatchlistTicker() {
  const raw = el.watchlistTickerInput ? el.watchlistTickerInput.value.trim() : '';
  if (!raw) {
    if (el.watchlistSearchError) {
      el.watchlistSearchError.textContent = t(state.lang, 'quote_input_placeholder');
      el.watchlistSearchError.classList.remove('hidden');
    }
    if (el.watchlistSearchResult) {
      el.watchlistSearchResult.classList.add('hidden');
      el.watchlistSearchResult.innerHTML = '';
    }
    state.watchlistSearchQuote = null;
    return;
  }
  if (el.watchlistSearchError) el.watchlistSearchError.classList.add('hidden');
  if (el.watchlistSearchResult) el.watchlistSearchResult.classList.add('hidden');
  if (el.watchlistSearch) {
    el.watchlistSearch.disabled = true;
    el.watchlistSearch.textContent = t(state.lang, 'quote_searching');
  }
  try {
    state.watchlistSearchQuote = await getQuoteByTicker(raw);
    renderWatchlistSearchCard();
  } catch (err) {
    if (el.watchlistSearchError) {
      el.watchlistSearchError.textContent = err && err.message ? err.message : '查询失败';
      el.watchlistSearchError.classList.remove('hidden');
    }
    state.watchlistSearchQuote = null;
  } finally {
    if (el.watchlistSearch) {
      el.watchlistSearch.disabled = false;
      el.watchlistSearch.textContent = t(state.lang, 'quote_search');
    }
  }
}

function renderAll() {
  if (state.summary && el.summaryRows) {
    el.summaryRows.innerHTML = renderSummaryRows(state.summary, state.lang);
  }
  if (state.summary && el.cashRows) {
    el.cashRows.innerHTML = renderCashRows(state.summary, state.lang);
  }
  if (el.positionsList) {
    el.positionsList.innerHTML = renderPositionsList(state.positions, state.sortKey, { clickable: true, lang: state.lang });
    el.positionsList.querySelectorAll('.position-card.clickable').forEach((card, i) => {
      card.addEventListener('click', () => {
        el.positionsList.querySelectorAll('.position-card.clickable').forEach((c, j) => c.classList.toggle('selected', j === i));
        showPositionDetail(i);
      });
      card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); card.click(); } });
    });
  }
  if (el.watchlistList) {
    if (state.watchlistError) {
      el.watchlistList.innerHTML = '<div class="hint-text">' + state.watchlistError + '</div>';
    } else {
      el.watchlistList.innerHTML = renderWatchlistList(state.watchlist, state.lang);
    }
  }
  renderWatchlistSearchCard();
  if (el.viewPositionDetail && el.viewPositionDetail.classList.contains('active') && state.currentDetailIndex != null) {
    showPositionDetail(state.currentDetailIndex);
  }
  updateLastUpdated();
}

function updateLastUpdated() {
  const text = formatLastUpdatedLabel(state.lastUpdated, state.autoRefreshSeconds);
  if (el.lastUpdatedStatus) el.lastUpdatedStatus.textContent = text;
  if (el.lastUpdatedStatusAnalysis) el.lastUpdatedStatusAnalysis.textContent = text;
}

const POLL_INTERVAL_MS = 5000;
const AUTO_REFRESH_SECONDS = 5;
const WATCHLIST_REFRESH_MS = 15000;
let autoRefreshTimer = null;
let pollTimer = null;

async function refreshWatchlistIfNeeded(config, forceRefresh) {
  if (!forceRefresh && state.watchlistLastUpdated && (Date.now() - state.watchlistLastUpdated < WATCHLIST_REFRESH_MS)) return;
  let watchlistItems = [];
  try {
    const items = await getWatchlistItems(config);
    watchlistItems = (Array.isArray(items) && items.length > 0)
      ? items
      : await getDefaultWatchlistWithQuotes(forceRefresh);
  } catch (err) {
    try {
      watchlistItems = await getDefaultWatchlistWithQuotes(forceRefresh);
    } catch (_) {
      watchlistItems = getDefaultWatchlistItems();
    }
  }
  try {
    const customItems = await getCustomWatchlistItems();
    watchlistItems = mergeWatchlistItems(watchlistItems, customItems);
  } catch (_) {}
  try {
    state.watchlist = await enrichWatchlistItemsWithQuotes(watchlistItems, forceRefresh);
  } catch (_) {
    state.watchlist = watchlistItems;
  }
  state.watchlistLastUpdated = Date.now();
  state.watchlistError = '';
}

async function load(forceRefresh = false, silent = false) {
  const now = Date.now();
  const rateLimitUntil = await getRateLimitUntil();
  if (now < rateLimitUntil) {
    if (!silent) {
      const sec = Math.ceil((rateLimitUntil - now) / 1000);
      setError(t(state.lang, 'error_rate_limit').replace('%s', String(sec)));
      show('error');
    }
    return;
  }
  if (autoRefreshTimer) {
    clearTimeout(autoRefreshTimer);
    autoRefreshTimer = null;
  }
  const config = await getConfig();
  state.lang = config.language === 'en' ? 'en' : 'zh';
  if (!silent) {
    applyTheme(config);
    applyI18n(state.lang);
  }
  if (!config.apiKey || !config.apiSecret) {
    if (!silent) show('empty');
    return;
  }
  if (!forceRefresh) {
    const cached = await getCachedData();
    if (cached) {
      state.summary = cached.summary;
      state.positions = cached.positions;
      state.cash = cached.summary;
      state.currency = (cached.summary && cached.summary.currency) || '';
      state.lastUpdated = cached.ts;
      state.autoRefreshSeconds = AUTO_REFRESH_SECONDS;
      await refreshWatchlistIfNeeded(config, forceRefresh);
      renderAll();
      if (!silent) show('content');
      return;
    }
  }
  if (!silent) {
    show('loading');
    if (el.loading) el.loading.classList.add('loading-dots');
    if (el.refresh) el.refresh.disabled = true;
  }
  try {
    const [summary, positions] = await Promise.all([getAccountSummary(), getPositions()]);
    await setCachedData(summary, Array.isArray(positions) ? positions : []);
    state.summary = summary;
    state.positions = Array.isArray(positions) ? positions : [];
    state.cash = summary;
    state.currency = summary.currency || '';
    state.lastUpdated = Date.now();
    state.autoRefreshSeconds = AUTO_REFRESH_SECONDS;
    await refreshWatchlistIfNeeded(config, forceRefresh);
    renderAll();
    if (!silent) show('content');
  } catch (err) {
    const status = err && err.status;
    if (status === 429) {
      let sec = 30;
      if (err.retryAfter) {
        const n = parseInt(err.retryAfter, 10);
        if (n > 0) sec = Math.min(n, 300);
      } else if (err.rateLimitReset) {
        const wait = Math.ceil((err.rateLimitReset * 1000 - Date.now()) / 1000);
        if (wait > 0) sec = Math.min(wait, 300);
      }
      const until = Date.now() + sec * 1000;
      await setRateLimitUntil(until);
      if (!silent) {
        setError(t(state.lang, 'error_rate_limit').replace('%s', String(sec)));
        show('error');
        if (el.refresh) el.refresh.disabled = true;
        setTimeout(async () => {
          await setRateLimitUntil(0);
          if (el.refresh) el.refresh.disabled = false;
        }, sec * 1000);
      }
      if (!silent && el.loading) el.loading.classList.remove('loading-dots');
      return;
    }
    if (!silent) {
      const msg = err instanceof Error ? err.message : (err && typeof err === 'object' ? (err.message || err.error || err.msg) : err);
      setError(msg);
    }
  } finally {
    if (!silent) {
      if (el.loading) el.loading.classList.remove('loading-dots');
      if (el.refresh) el.refresh.disabled = false;
    }
  }
}

function startPolling() {
  if (pollTimer) return;
  state.autoRefreshSeconds = AUTO_REFRESH_SECONDS;
  updateLastUpdated();
  pollTimer = setInterval(() => {
    load(false, true);
  }, POLL_INTERVAL_MS);
}

// 持仓排序
if (el.positionsSort) {
  el.positionsSort.addEventListener('change', () => {
    state.sortKey = el.positionsSort.value;
    renderAll();
  });
}

if (el.detailBack) el.detailBack.addEventListener('click', backFromDetail);
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape' && el.viewPositionDetail && el.viewPositionDetail.classList.contains('active')) {
    backFromDetail();
  }
});
if (el.refresh) el.refresh.addEventListener('click', () => load(true));
const retryBtn = document.getElementById('retryBtn');
if (retryBtn) retryBtn.addEventListener('click', () => load(true));
if (el.openOptions) el.openOptions.addEventListener('click', function(e) {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});
if (el.statusBarOptions) {
  el.statusBarOptions.addEventListener('click', function(e) {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });
}
if (el.statusBarSidePanel) {
  el.statusBarSidePanel.addEventListener('click', function(e) {
    e.preventDefault();
    chrome.windows.getCurrent(win => {
      if (win && win.id != null) chrome.sidePanel.open({ windowId: win.id });
    });
  });
}
if (el.themeToggle) {
  el.themeToggle.addEventListener('click', function() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const next = current === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', next);
    chrome.storage.local.set({ theme: next });
    el.themeToggle.title = next === 'light' ? t(state.lang, 'theme_switch_dark') : t(state.lang, 'theme_switch_light');
  });
}
if (el.btnAnalysis) {
  el.btnAnalysis.addEventListener('click', () => showView('analysis'));
}
if (el.btnWatchlist) {
  el.btnWatchlist.addEventListener('click', () => showView('watchlist'));
}
if (el.statusBarSidePanelFromAnalysis) {
  el.statusBarSidePanelFromAnalysis.addEventListener('click', function(e) {
    e.preventDefault();
    chrome.windows.getCurrent(win => {
      if (win && win.id != null) chrome.sidePanel.open({ windowId: win.id });
    });
  });
}
if (el.analysisBack) {
  el.analysisBack.addEventListener('click', () => showView('main'));
}
if (el.watchlistBack) {
  el.watchlistBack.addEventListener('click', () => showView('main'));
}
if (el.watchlistSearch) {
  el.watchlistSearch.addEventListener('click', () => { searchWatchlistTicker(); });
}
if (el.watchlistTickerInput) {
  el.watchlistTickerInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      searchWatchlistTicker();
    }
  });
}
if (el.statusBarOptionsFromAnalysis) {
  el.statusBarOptionsFromAnalysis.addEventListener('click', function(e) {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });
}
if (el.analysisModelSelect) {
  el.analysisModelSelect.addEventListener('change', function() {
    chrome.storage.local.set({ openRouterModel: this.value });
  });
}
if (el.analysisLanguageSelect) {
  el.analysisLanguageSelect.addEventListener('change', function() {
    chrome.storage.local.set({ analysisLanguage: this.value });
    syncAnalysisPromptEditor(true);
  });
}
if (el.analysisResetPrompt) {
  el.analysisResetPrompt.addEventListener('click', () => {
    syncAnalysisPromptEditor(true);
  });
}
if (el.analysisCopyPrompt) {
  el.analysisCopyPrompt.addEventListener('click', async () => {
    const text = (el.analysisPromptInput && el.analysisPromptInput.value.trim()) ? el.analysisPromptInput.value : getDefaultAnalysisPrompt();
    try {
      await navigator.clipboard.writeText(text);
      if (el.analysisPromptStatus) {
        el.analysisPromptStatus.textContent = t(state.lang, 'analysis_prompt_copied');
        el.analysisPromptStatus.classList.remove('hidden');
        setTimeout(() => { if (el.analysisPromptStatus) el.analysisPromptStatus.classList.add('hidden'); }, 3000);
      }
    } catch (e) {
      if (el.analysisError) {
        el.analysisError.textContent = (e && e.message) || '复制失败';
        el.analysisError.classList.remove('hidden');
      }
    }
  });
}
if (el.analysisOpenMiroMindSite) {
  el.analysisOpenMiroMindSite.addEventListener('click', async () => {
    const config = await getConfig();
    const url = (config.miroMindUrl || 'https://dr.miromind.ai/').replace(/\/$/, '') || 'https://dr.miromind.ai';
    window.open(url, '_blank');
  });
}
if (el.analysisOpenChatGPTSite) {
  el.analysisOpenChatGPTSite.addEventListener('click', () => {
    window.open('https://chatgpt.com/', '_blank');
  });
}
if (el.analysisOpenPerplexitySite) {
  el.analysisOpenPerplexitySite.addEventListener('click', () => {
    window.open('https://www.perplexity.ai/', '_blank');
  });
}
if (el.analysisCopyAndOpenMiroMind) {
  el.analysisCopyAndOpenMiroMind.addEventListener('click', async function() {
    const config = await getConfig();
    const prompt = (el.analysisPromptInput && el.analysisPromptInput.value.trim()) ? el.analysisPromptInput.value : getDefaultAnalysisPrompt();
    try {
      await navigator.clipboard.writeText(prompt);
      const url = (config.miroMindUrl || 'https://dr.miromind.ai/').replace(/\/$/, '') || 'https://dr.miromind.ai';
      window.open(url, '_blank');
      if (el.analysisMiroMindStatus) {
        el.analysisMiroMindStatus.textContent = t(state.lang, 'analysis_copied_open');
        el.analysisMiroMindStatus.classList.remove('hidden');
        setTimeout(() => { if (el.analysisMiroMindStatus) { el.analysisMiroMindStatus.classList.add('hidden'); } }, 4000);
      }
    } catch (e) {
      if (el.analysisError) {
        el.analysisError.textContent = (e && e.message) || '复制失败';
        el.analysisError.classList.remove('hidden');
      }
    }
  });
}
if (el.analysisGenerate) {
  el.analysisGenerate.addEventListener('click', async function() {
    const config = await getConfig();
    if (!config.customAnalysisApiUrl && !config.openRouterApiKey) {
      if (el.analysisError) {
        el.analysisError.textContent = t(state.lang, 'analysis_no_key');
        el.analysisError.classList.remove('hidden');
      }
      if (el.analysisResult) el.analysisResult.classList.add('hidden');
      return;
    }
    const model = el.analysisModelSelect ? el.analysisModelSelect.value : config.openRouterModel;
    const effectiveLang = getEffectiveAnalysisLang();
    const promptInput = el.analysisPromptInput ? el.analysisPromptInput.value.trim() : '';
    const customPrompt = !config.customAnalysisApiUrl && promptInput ? promptInput : '';
    if (el.analysisError) el.analysisError.classList.add('hidden');
    if (el.analysisResult) el.analysisResult.classList.add('hidden');
    el.analysisGenerate.disabled = true;
    el.analysisGenerate.textContent = t(state.lang, 'analysis_loading');
    try {
      const text = await getMarketAnalysisFromConfig(config, state.positions, state.summary, effectiveLang, model, customPrompt);
      if (el.analysisResult) {
        el.analysisResult.textContent = text;
        el.analysisResult.classList.remove('hidden');
      }
    } catch (err) {
      if (el.analysisError) {
        el.analysisError.textContent = err && err.message ? err.message : t(state.lang, 'analysis_error');
        el.analysisError.classList.remove('hidden');
      }
    } finally {
      el.analysisGenerate.disabled = false;
      el.analysisGenerate.textContent = t(state.lang, 'analysis_generate_in_extension');
    }
  });
}

getConfig().then(config => {
  state.lang = config.language === 'en' ? 'en' : 'zh';
  applyTheme(config);
  applyI18n(state.lang);
  load(false).then(() => { startPolling(); });
});
